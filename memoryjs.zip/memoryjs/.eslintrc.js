module.exports = {
  root: true,
  parserOptions: {
    sourceType: 'module'
  },
  extends: 'airbnb-base',
  rules: {
    'linebreak-style': 0,
    'import/no-unresolved': 0,
  },
};
