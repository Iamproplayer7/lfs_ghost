#pragma once
#ifndef MEMORYJS_H
#define MEMORYJS_H
#define WIN32_LEAN_AND_MEAN

#include <windows.h>

class memoryjs {

public:
  memoryjs();
  ~memoryjs();
};
#endif
#pragma once
